<!-- Header Section -->
<div class="row mb-4">
	<div class="col-md-6">
		<div class="mb-3">
			<label for="nama_pasien" class="form-label">Nama Pasien</label>
			<input type="text" class="form-control border-dark" id="nama_pasien" name="nama_pasien">
		</div>
		<div class="mb-3">
			<label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
			<input type="text" class="form-control border-dark" id="tanggal_lahir" name="tanggal_lahir">
		</div>
		<div class="mb-3">
			<label for="no_rm" class="form-label">No. RM</label>
			<input type="text" class="form-control border-dark" id="no_rm" name="no_rm">
		</div>
		<div class="mb-3">
			<label for="dokter_jaga" class="form-label">Dokter Jaga</label>
			<input type="text" class="form-control border-dark" id="dokter_jaga" name="nama_dokter">
		</div>
		<div class="mb-3">
			<label for="nama_dokter" class="form-label">DPJP</label>
			<input type="text" class="form-control border-dark" id="nama_dokter" name="nama_dokter" disabled>
		</div>
		<div class="mb-3 d-flex flex-column">
			<label for="diagnosa" class="form-label">Diagnosa</label>
			<select type="select" name="diagnosa1" class="form-select diagnosa ">
			</select>
		</div>
	</div>
	<div class="col-md-6">
		<div class="mb-3">
			<label for="tgl_admit" class="form-label">Tanggal Masuk</label>
			<input type="text" class="form-control border-dark" id="tgl_admit" name="tgl_admit">
		</div>
		<div class="mb-3">
			<label for="nama_ruangan" class="form-label">Ruangan</label>
			<input type="text" class="form-control border-dark" id="nama_ruangan" name="nama_ruangan">
		</div>
		<div class="mb-3">
			<label for="tgl_jam_pindah" class="form-label">Tgl / Jam Pindah</label>
			<input type="datetime-local" class="form-control border-dark" id="tgl_jam_pindah" name="tgl_jam_pindah"
				value="<?= date('Y-m-d H:i') ?>">
		</div>
		<div class="mb-3">
			<label for="pindah_ke_ruangan" class="form-label">Pindah ke Ruangan</label>
			<input type="text" class="form-control border-dark" id="pindah_ke_ruangan" name="pindah_ke_ruangan">
		</div>
		<div class="mb-3">
			<label for="diagnosa_sekarang" class="form-label">Diagnosa Sekarang</label>
			<select type="select" name="diagnosa1" class="form-select diagnosa ">
			</select>
		</div>
	</div>
</div>

<!-- Pengkajian Section -->
<div class="card mb-4">
	<div class="card-header">
		<h5 class="mb-0">I. PENGKAJIAN</h5>
	</div>
	<div class="card-body">
		<div class="mb-3">
			<label for="keluhan_utama" class="form-label">A. Keluhan Utama</label>
			<textarea class="form-control border-dark" id="keluhan_utama" name="keluhan_utama" rows="3"></textarea>
		</div>
		<div class="mb-3">
			<label for="riwayat_penyakit" class="form-label">B. Riwayat Penyakit</label>
			<textarea class="form-control border-dark" id="riwayat_penyakit" name="riwayat_penyakit" rows="3"></textarea>
		</div>
	</div>
</div>

<!-- Pemeriksaan Fisik Section -->
<div class="card mb-4">
	<div class="card-header">
		<h5 class="mb-0">II. PEMERIKSAAN FISIK</h5>
	</div>
	<div class="card-body">
		<div class="mb-3">
			<label for="keadaan_umum" class="form-label">A. Keadaan Umum</label>
			<input type="text" class="form-control border-dark" id="keadaan_umum" name="keadaan_umum">
		</div>

		<div class="row mb-3">
			<div class="col-md-3">
				<label for="tekanan_darah" class="form-label">TD (mmHg)</label>
				<input type="text" class="form-control border-dark" id="tekanan_darah" name="tekanan_darah">
			</div>
			<div class="col-md-3">
				<label for="nadi" class="form-label">Nadi (x/i)</label>
				<input type="text" class="form-control border-dark" id="nadi" name="nadi">
			</div>
			<div class="col-md-3">
				<label for="skala_nyeri" class="form-label">Skala Nyeri</label>
				<input type="text" class="form-control border-dark" id="skala_nyeri" name="skala_nyeri">
			</div>
		</div>

		<div class="row mb-3">
			<div class="col-md-3">
				<label for="pernafasan" class="form-label">Pernafasan (x/i)</label>
				<input type="text" class="form-control border-dark" id="pernafasan" name="pernafasan">
			</div>
			<div class="col-md-3">
				<label for="suhu" class="form-label">Suhu (°C)</label>
				<input type="text" class="form-control border-dark" id="suhu" name="suhu">
			</div>
		</div>

		<div class="mb-3">
			<label for="pemeriksaan_fisik" class="form-label">C. Pemeriksaan Fisik</label>
			<textarea class="form-control border-dark" id="pemeriksaan_fisik" name="pemeriksaan_fisik" rows="3"></textarea>
		</div>

		<div class="mb-3">
			<label for="riwayat_alergi" class="form-label">D. Riwayat Alergi</label>
			<input type="text" class="form-control border-dark" id="riwayat_alergi" name="riwayat_alergi">
		</div>

		<div class="mb-3">
			<label for="alasan_pindah_ruangan" class="form-label">E. Alasan Pindah Ruangan</label>
			<input type="text" class="form-control border-dark" id="alasan_pindah_ruangan" name="alasan_pindah_ruangan">
		</div>
	</div>
</div>

<!-- Pemeriksaan Penunjang Section -->
<div class="card mb-4">
	<div class="card-header">
		<h5 class="mb-0">III. PEMERIKSAAN PENUNJANG / DIAGNOSTIK</h5>
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-3">
				<div class="form-check">
					<input class="custom-checkbox-success" type="radio" name="pemeriksaan_penunjang" id="laboratorium">
					<label class="form-check-label" for="laboratorium">Laboratorium</label>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-check">
					<input class="custom-checkbox-success" type="radio" name="pemeriksaan_penunjang" id="ekg">
					<label class="form-check-label" for="ekg">EKG</label>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-check">
					<input class="custom-checkbox-success" type="radio" name="pemeriksaan_penunjang" id="radiologi">
					<label class="form-check-label" for="radiologi">Radiologi</label>
				</div>
			</div>
			<div class="col-md-3">
				<input type="radio" class="custom-checkbox-success" name="pemeriksaan_penunjang" id="lain_lain" onclick="toggleInputLain(true)">
				<label for="lain_lain" class="form-label">Lain-lain</label>
				<input type="text" class="form-control border-dark" id="lain_lain_input" name="lain_lain_input" readonly>
			</div>
		</div>

	</div>
</div>

<!-- Pemberian Terapi Section -->
<div class="card mb-2">
	<div class="card-header">
		<h5 class="mb-0">IV. PEMBERIAN TERAPI</h5>
	</div>
	<div class="card-body">
		<div class="mb-3">
			<textarea class="form-control border-dark" id="pemberian_terapi" name="pemberian_terapi" rows="4"></textarea>
		</div>
	</div>
</div>

<!-- Tindakan Medis Section -->
<div class="card mb-2">
	<div class="card-header">
		<h5 class="mb-0">V. TINDAKAN MEDIS YANG TELAH DILAKUKAN</h5>
	</div>
	<div class="card-body">
		<div class="mb-3">
			<textarea class="form-control border-dark" id="tindakan_medis" name="tindakan_medis" rows="4"></textarea>
		</div>
	</div>
</div>

<!-- Diet Section -->
<div class="card mb-2">
	<div class="card-header">
		<h5 class="mb-0">VI. DIET</h5>
	</div>
	<div class="card-body">
		<div class="mb-3">
			<textarea name="diet_1" id="diet_1" class="form-control border-dark" rows="4"></textarea>
		</div>
	</div>
</div>

<!-- Indikasi Pasien Masuk Section -->
<div class="card mb-2">
	<div class="card-header">
		<h5 class="mb-0">VII. INDIKASI PASIEN MASUK</h5>
	</div>
	<div class="card-body">
		<div class="mb-3">
			<textarea class="form-control border-dark" id="indikasi_pasien_masuk" name="indikasi_pasien_masuk" rows="3"></textarea>
		</div>
		<div class="row">
			<div class="col-md-3">
				<div class="form-check">
					<input class="custom-checkbox-success" type="radio" name="indikasi_type" id="preventif">
					<label class="form-check-label" for="preventif">Preventif</label>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-check">
					<input class="custom-checkbox-success" type="radio" name="indikasi_type" id="kuratif">
					<label class="form-check-label" for="kuratif">Kuratif</label>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-check">
					<input class="custom-checkbox-success" type="radio" name="indikasi_type" id="paliatif">
					<label class="form-check-label" for="paliatif">Paliatif</label>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-check">
					<input class="custom-checkbox-success" type="radio" name="indikasi_type" id="rehabilitatif">
					<label class="form-check-label" for="rehabilitatif">Rehabilitatif</label>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Kondisi Pasien Section -->
<div class="card mb-2">
	<div class="card-header">
		<h5 class="mb-0">VIII. KONDISI PASIEN SAAT TRANSFER</h5>
	</div>
	<div class="card-body">
		<div class="mb-3">
			<textarea class="form-control border-dark" id="kondisi_pasien" name="kondisi_pasien" rows="3"></textarea>
		</div>
	</div>
</div>

<!-- Signature Section -->
<div class="row mt-4">
	<div class="col-md-6">
		<div class="mb-3 d-flex flex-column gap-3 align-items-center">
			<label for="perawat_menyerahkan" class="form-label">Perawat yang menyerahkan</label>
			<img class="img-responsive center-block mt-2" style="width: 20%;" id="qr_perawat_menyerahkan" />
			<select type="select" name="perawat_menyerahkan" id="perawat_menyerahkan" class="form-select"
				style="width: 100%;"></select>
		</div>
	</div>
	<div class="col-md-6">
		<div class="mb-3 d-flex flex-column gap-3 align-items-center">
			<label for="perawat_menerima" class="form-label">Perawat yang menerima</label>
			<img class="img-responsive center-block mt-2" style="width: 20%;" id="qr_perawat_menerima" />
			<select type="select" name="perawat_menerima" id="perawat_menerima" class="form-select"
				style="width: 100%;"></select>
		</div>
	</div>
</div>

<script>
	const mode = "<?= $mode; ?>"
	let dataListPerawatMenyerahkan = []
	let dataListPerawatMenerima = []

	function cbCommon() {
		$('#perawat_menyerahkan').prop('disabled', false)
		$('#perawat_menyerahkan').select2('open')
		$('#perawat_menyerahkan').select2('close')
		$('#perawat_menerima').prop('disabled', false)
		$('#perawat_menerima').select2('open')
		$('#perawat_menerima').select2('close')
		if (mode === "lihat") {
			$('#perawat_menyerahkan').prop('disabled', true)
			$('#perawat_menerima').prop('disabled', true)

		}

		setTimeout(() => {
			dataListPerawatMenyerahkan?.map(v => {
				if (v.text === $('#perawat_menyerahkan').select2('data')[0].text) {
					QRSignatureAPI(v.id_original, 'qr_perawat_menyerahkan')
				}
			})
			dataListPerawatMenerima?.map(v => {
				if (v.text === $('#perawat_menerima').select2('data')[0].text) {
					QRSignatureAPI(v.id_original, 'qr_perawat_menerima')
				}
			})
		}, 1000)
	}

	$(document).ready(function() {
		let page = 1;

		listPerawatAPI()

		$('.diagnosa').select2({
			ajax: {
				url: '<?= site_url('backend/admission/getDiagnosa'); ?>', // PHP script to fetch data
				dataType: 'json',
				delay: 250, // Delay in ms while typing
				data: function(params) {
					console.log("params", params)
					return {
						q: params.term, // Search query
						limit: 100, // Number of items per page
						offset: (page - 1) * 100, // Calculate offset
					};
				},
				processResults: function(data) {
					const {
						items,
						more
					} = data.data
					console.log(items, more)
					return {
						results: items, // Data from PHP
						pagination: {
							more: more, // Check if more data is available
						},
					};
				},
				cache: true,
			},
			placeholder: 'Search for items...',
			// minimumInputLength: 0,
		});
		$('.diagnosa').on('select2:open', function() {
			$('.select2-results__options').on('scroll', function() {
				const $this = $(this);
				if ($this.scrollTop() + $this.innerHeight() >= $this[0].scrollHeight) {
					page++; // Increment page
					$('.diagnosa').select2('data', null); // Trigger new data fetch
				}
			});
		});

		$('#perawat_menyerahkan').on('select2:select', function(e) {
			const {
				id_original
			} = e.params.data;
			QRSignatureAPI(id_original, 'qr_perawat_menyerahkan')
		});
		$('#perawat_menerima').on('select2:select', function(e) {
			const {
				id_original
			} = e.params.data;
			QRSignatureAPI(id_original, 'qr_perawat_menerima')
		});
	});

	function listPerawatAPI() {
		$('#perawat_menyerahkan').select2({
			ajax: {
				url: '<?= site_url('backend/admission/getKaryawan/13'); ?>',
				dataType: 'json',
				delay: 250,
				data: function(params) {
					return {
						q: params.term,
					}
				},
				processResults: function(data) {
					const {
						items,
						more
					} = data.data;
					dataListPerawatMenyerahkan = items
					return {
						results: items, // Data from PHP
						pagination: {
							more: more, // Check if more data is available
						},
					};
				},
				cache: true,

			},
			placeholder: 'Search for items...',
		})

		$('#perawat_menerima').select2({
			ajax: {
				url: '<?= site_url('backend/admission/getKaryawan/13'); ?>',
				dataType: 'json',
				delay: 250,
				data: function(params) {
					return {
						q: params.term,
					}
				},
				processResults: function(data) {
					const {
						items,
						more
					} = data.data;
					dataListPerawatMenerima = items
					return {
						results: items, // Data from PHP
						pagination: {
							more: more, // Check if more data is available
						},
					};
				},
				cache: true,

			},
			placeholder: 'Search for items...',
		})
	}

	// Get the elements
	const lainLainRadio = document.getElementById('lain_lain');
	const lainLainInput = document.getElementById('lain_lain_input');
	const otherRadios = document.querySelectorAll('input[name="pemeriksaan_penunjang"]:not(#lain_lain)');

	// Add event listener for "Lain-lain" radio button
	lainLainRadio.addEventListener('change', function() {
		if (this.checked) {
			lainLainInput.focus(); // Focus the input field when "Lain-lain" is selected
		}
	});

	// Add event listeners for other radio buttons
	otherRadios.forEach(radio => {
		radio.addEventListener('change', function() {
			if (this.checked) {
				lainLainInput.value = ''; // Clear the value of the input field when another radio is selected
			}
		});
	});

	// Fungsi untuk mengaktifkan dan menonaktifkan input berdasarkan pilihan radio button
	function toggleInputLain(enable = false) {
		const lainLainInput = document.getElementById('lain_lain_input');

		if (enable) {
			lainLainInput.readOnly = false; // Mengaktifkan input untuk "Lain-lain"
			lainLainInput.focus(); // Memberikan fokus pada input
		} else {
			lainLainInput.readOnly = true; // Menonaktifkan input jika radio lain dipilih
			lainLainInput.value = ''; // Mengosongkan nilai input jika radio lain dipilih
			lainLainInput.blur(); // Menghilangkan fokus dari input
		}
	}

	// Menonaktifkan input saat halaman pertama kali dimuat
	document.addEventListener("DOMContentLoaded", function() {
		toggleInputLain(false); // Menonaktifkan input jika radio button tidak dipilih
	});
</script>